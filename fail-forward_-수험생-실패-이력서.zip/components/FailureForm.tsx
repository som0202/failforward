
import React, { useState } from 'react';
import { FailureCategory, FAILURE_TAGS, FailureLog } from '../types';
import { Plus, Loader2, Target, Globe, Lock, Coins } from 'lucide-react';
import { analyzeFailure } from '../services/geminiService';

interface Props {
  onAdd: (log: FailureLog) => void;
}

export const FailureForm: React.FC<Props> = ({ onAdd }) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<FailureCategory>('Mock Exam');
  const [description, setDescription] = useState('');
  const [score, setScore] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [isPublic, setIsPublic] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  const toggleTag = (label: string) => {
    setSelectedTags(prev => 
      prev.includes(label) ? prev.filter(t => t !== label) : [...prev, label]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description) return;

    setIsLoading(true);
    const newLogBase = {
      title,
      date: new Date().toISOString().split('T')[0],
      category,
      score,
      tags: selectedTags,
      description,
    };

    const aiAdvice = await analyzeFailure(newLogBase);

    const newLog: FailureLog = {
      ...newLogBase,
      id: crypto.randomUUID(),
      authorId: 'me',
      authorName: '나',
      aiAdvice,
      createdAt: Date.now(),
      likes: 0,
      dislikes: 0,
      isPublic,
      rewardClaimed: false
    };

    onAdd(newLog);
    setIsLoading(false);
    resetForm();
  };

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setScore('');
    setSelectedTags([]);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-slate-800 p-6 rounded-3xl shadow-xl border border-slate-700 relative overflow-hidden">
      <div className="absolute top-0 right-0 bg-amber-500/10 text-amber-500 px-4 py-1 text-[10px] font-bold rounded-bl-xl flex items-center gap-1">
        <Coins size={12} /> 작성 시 +500P
      </div>
      
      <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
        <Target className="text-red-500" /> 망한 기록 작성하기
      </h2>
      
      <div className="space-y-4">
        <input
          type="text"
          placeholder="실패 제목 (예: 9월 모의고사 수학 대참사)"
          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-red-500"
          value={title}
          onChange={e => setTitle(e.target.value)}
          required
        />

        <div className="flex gap-4">
          <select 
            className="flex-1 bg-slate-900 border border-slate-700 rounded-xl p-3"
            value={category}
            onChange={e => setCategory(e.target.value as FailureCategory)}
          >
            <option value="Mock Exam">모의고사/정기시험</option>
            <option value="Daily Plan">일일 계획/루틴</option>
            <option value="Health/Mental">건강/멘탈 관리</option>
            <option value="Study Method">학습 방법</option>
            <option value="Mock Interview">모의 면접/발표</option>
          </select>
          <input
            type="text"
            placeholder="결과/점수 (선택)"
            className="flex-1 bg-slate-900 border border-slate-700 rounded-xl p-3"
            value={score}
            onChange={e => setScore(e.target.value)}
          />
        </div>

        <div className="flex flex-wrap gap-2">
          {FAILURE_TAGS.map(tag => (
            <button
              key={tag.id}
              type="button"
              onClick={() => toggleTag(tag.label)}
              className={`px-3 py-1 rounded-full text-xs transition-colors border ${
                selectedTags.includes(tag.label) 
                  ? 'bg-red-500 border-red-400 text-white' 
                  : 'bg-slate-900 border-slate-700 text-slate-400 hover:border-slate-500'
              }`}
            >
              {tag.label}
            </button>
          ))}
        </div>

        <textarea
          placeholder="왜 망했는지 솔직하게 기록해봅시다. (기분이 어땠는지, 어떤 실수를 했는지...)"
          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 h-32 resize-none focus:outline-none focus:ring-2 focus:ring-red-500"
          value={description}
          onChange={e => setDescription(e.target.value)}
          required
        />

        <div className="flex items-center justify-between p-3 bg-slate-900 rounded-xl border border-slate-700">
          <div className="flex items-center gap-3">
            {isPublic ? <Globe size={18} className="text-blue-400" /> : <Lock size={18} className="text-slate-500" />}
            <div>
              <p className="text-sm font-bold text-slate-200">커뮤니티 공개 여부</p>
              <p className="text-[10px] text-slate-500">공개 시 다른 유저에게 도움을 주고 포인트를 얻습니다.</p>
            </div>
          </div>
          <button 
            type="button"
            onClick={() => setIsPublic(!isPublic)}
            className={`w-12 h-6 rounded-full transition-colors relative ${isPublic ? 'bg-red-500' : 'bg-slate-700'}`}
          >
            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${isPublic ? 'left-7' : 'left-1'}`} />
          </button>
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-all disabled:opacity-50"
        >
          {isLoading ? (
            <><Loader2 className="animate-spin" /> 분석하는 중...</>
          ) : (
            <><Plus size={20} /> 실패 등록하고 500P 받기</>
          )}
        </button>
      </div>
    </form>
  );
};
