
import { GoogleGenAI } from "@google/genai";
import { FailureLog } from "../types";

// Initialize the Gemini API client with the environment variable API_KEY.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Analyzes a student's failure log and returns AI-generated advice and peer comparison.
 */
export const analyzeFailure = async (log: Pick<FailureLog, 'title' | 'category' | 'tags' | 'description' | 'score'>): Promise<string> => {
  const prompt = `
    수험생이 작성한 실패 기록을 분석하고, 다음 도전을 위한 '주의사항 및 솔루션'을 작성해줘.
    
    기록 제목: ${log.title}
    카테고리: ${log.category}
    실패 원인 태그: ${log.tags.join(', ')}
    내용 상세: ${log.description}
    ${log.score ? `점수/결과: ${log.score}` : ''}

    요청 사항:
    1. 따뜻하면서도 분석적인 톤앤매너 유지.
    2. '망한 원인'에 대한 근본적인 인사이트 1가지 제공.
    3. **비슷한 실패를 겪은 다른 수험생들의 일반적인 사례와 비교 분석**하여, 이것이 개인만의 문제가 아니라 수험 과정에서 흔히 발생하는 패턴인지, 그리고 다른 이들은 어떻게 극복했는지 언급해줘.
    4. 다음번에는 같은 실수를 반복하지 않기 위한 구체적인 '행동 강령' 3가지 제안.
    5. 한국어로 작성하며 섹션을 명확히 구분해줘.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        temperature: 0.7,
        topP: 0.8,
      }
    });

    return response.text || "분석 결과를 가져오는데 실패했습니다.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "현재 AI 분석 기능을 사용할 수 없습니다. 잠시 후 다시 시도해주세요.";
  }
};
