
import React, { useState, useEffect } from 'react';
import { FailureLog, UserProfile, STORE_ITEMS } from './types';
import { FailureForm } from './components/FailureForm';
import { FailureChart } from './components/FailureChart';
import { Store } from './components/Store';
import { 
  History, 
  Trash2, 
  Sparkles, 
  Quote, 
  AlertCircle,
  LayoutDashboard,
  Frown,
  Users,
  Store as StoreIcon,
  ThumbsUp,
  ThumbsDown,
  Lock,
  Coins,
  Search,
  Eye,
  Unlock
} from 'lucide-react';

const MOCK_COMMUNITY: FailureLog[] = [
  {
    id: 'mock-1',
    authorId: 'user-77',
    authorName: '의대지망생_A',
    title: '6월 학평 국어 시간부족 대참사',
    date: '2024-06-15',
    category: 'Mock Exam',
    tags: ['시간 조절 실패', '긴장/불안감'],
    description: '비문학 마지막 지문 하나를 통째로 날렸습니다. 처음에 너무 꼼꼼하게 읽으려다가 망했네요. 실전에서는 과감함이 필요하다는 걸 뼈저리게 느꼈습니다.',
    aiAdvice: '### 근본 원인 인사이트\n완벽주의적 독해가 오히려 전반적인 시간 관리를 무너뜨렸습니다.\n\n### 다른 수험생들과의 비교\n많은 상위권 학생들이 겪는 전형적인 "매몰 현상"입니다. 보통 이런 경우 한 지문에 15분 이상을 쓰다가 멘탈이 흔들려 뒷부분을 마킹도 못하는 경우가 많습니다. 합격생들은 이를 방지하기 위해 지문당 "데드라인"을 설정합니다.\n\n### 행동 강령\n1. 지문당 시간 한계선 설정\n2. 쉬운 문제부터 풀기\n3. 매일 아침 시간 재고 풀기',
    createdAt: Date.now() - 1000000,
    likes: 42,
    dislikes: 2,
    isPublic: true,
    rewardClaimed: true
  },
  {
    id: 'mock-2',
    authorId: 'user-99',
    authorName: 'N수생의외침',
    title: '밤샘 공부 후 다음날 리듬 붕괴',
    date: '2024-08-01',
    category: 'Daily Plan',
    tags: ['수면 부족', '번아웃'],
    description: '새벽 4시까지 공부하고 다음날 11시에 일어났더니 하루 전체 계획이 꼬여버렸습니다. 결국 어제 한 거보다 오늘 못한 게 더 많네요.',
    aiAdvice: '### 근본 원인 인사이트\n단기적 몰입이 장기적 시스템을 파괴한 전형적인 오버페이스 사례입니다.\n\n### 다른 수험생들과의 비교\n시험 직전 불안감에 휩싸인 수험생의 60% 이상이 밤샘을 시도하지만, 결과적으로 다음날 학습 효율은 평소의 30% 이하로 떨어집니다. 성공한 N수생들은 밤샘 대신 일찍 자고 새벽에 일어나는 방식을 선호합니다.\n\n### 행동 강령\n1. 최소 수면 6시간 사수\n2. 취침 1시간 전 스마트폰 차단\n3. 루틴 붕괴 시 즉각 휴식 후 정비',
    createdAt: Date.now() - 500000,
    likes: 85,
    dislikes: 5,
    isPublic: true,
    rewardClaimed: true
  }
];

const VIEW_COST = 100;

const App: React.FC = () => {
  const [logs, setLogs] = useState<FailureLog[]>([]);
  const [user, setUser] = useState<UserProfile>({
    id: 'me',
    name: '김수험',
    points: 1000,
    hasContributed: false,
    inventory: [],
    unlockedLogIds: []
  });
  const [activeTab, setActiveTab] = useState<'history' | 'stats' | 'community' | 'store'>('history');

  useEffect(() => {
    const savedLogs = localStorage.getItem('fail-forward-logs');
    const savedUser = localStorage.getItem('fail-forward-user');
    if (savedLogs) setLogs(JSON.parse(savedLogs));
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('fail-forward-user', JSON.stringify(user));
  }, [user]);

  const addLog = (log: FailureLog) => {
    const newLogs = [log, ...logs];
    setLogs(newLogs);
    localStorage.setItem('fail-forward-logs', JSON.stringify(newLogs));
    
    const reward = 500;
    setUser(prev => ({
      ...prev,
      points: prev.points + reward,
      hasContributed: true
    }));

    alert(`${reward}P가 지급되었습니다! 이제 커뮤니티를 이용할 수 있습니다.`);
  };

  const deleteLog = (id: string) => {
    const filtered = logs.filter(log => log.id !== id);
    setLogs(filtered);
    localStorage.setItem('fail-forward-logs', JSON.stringify(filtered));
  };

  const handleUnlock = (logId: string) => {
    if (user.points < VIEW_COST) {
      alert('포인트가 부족합니다!');
      return;
    }
    if (user.unlockedLogIds.includes(logId)) return;

    setUser(prev => ({
      ...prev,
      points: prev.points - VIEW_COST,
      unlockedLogIds: [...prev.unlockedLogIds, logId]
    }));
  };

  const handlePurchase = (price: number, itemId: string) => {
    if (user.points < price) return;
    setUser(prev => ({
      ...prev,
      points: prev.points - price,
      inventory: [...prev.inventory, itemId]
    }));
    alert('구매가 완료되었습니다! 보관함을 확인하세요.');
  };

  const handleLike = (logId: string) => {
    alert('이 기록이 도움이 된다고 표시했습니다!');
  };

  const communityLogs = [...MOCK_COMMUNITY, ...logs.filter(l => l.isPublic)];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="hidden md:flex w-72 flex-col bg-slate-900 border-r border-slate-800 p-6 sticky top-0 h-screen">
        <div className="flex items-center gap-2 mb-10">
          <div className="bg-red-600 p-2 rounded-lg">
            <Frown className="text-white" size={24} />
          </div>
          <h1 className="text-xl font-black tracking-tighter">FAIL-FORWARD</h1>
        </div>

        <nav className="flex-1 space-y-2">
          <button 
            onClick={() => setActiveTab('history')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'history' ? 'bg-slate-800 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
          >
            <LayoutDashboard size={20} />
            <span>기록 피드</span>
          </button>
          <button 
            onClick={() => setActiveTab('community')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'community' ? 'bg-slate-800 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
          >
            <Users size={20} />
            <span>실패 커뮤니티</span>
          </button>
          <button 
            onClick={() => setActiveTab('stats')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'stats' ? 'bg-slate-800 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
          >
            <History size={20} />
            <span>데이터 분석</span>
          </button>
          <button 
            onClick={() => setActiveTab('store')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'store' ? 'bg-slate-800 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
          >
            <StoreIcon size={20} />
            <span>포인트 상점</span>
          </button>
        </nav>

        <div className="mt-auto bg-amber-500/10 p-4 rounded-xl border border-amber-500/20">
          <div className="flex items-center justify-between mb-2">
             <p className="text-[10px] text-amber-500 font-bold uppercase tracking-wider">내 지갑</p>
             <Coins size={14} className="text-amber-500" />
          </div>
          <p className="text-xl font-black text-amber-500">{user.points.toLocaleString()} P</p>
          <button onClick={() => setActiveTab('store')} className="text-[10px] text-amber-400 mt-2 hover:underline">기프티콘 보러가기 →</button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-10 max-w-4xl mx-auto w-full pb-24">
        {/* Mobile Header */}
        <div className="md:hidden flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
             <div className="bg-red-600 p-1.5 rounded-lg">
              <Frown className="text-white" size={18} />
            </div>
            <h1 className="font-bold">Fail-Forward</h1>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setActiveTab('history')} className={`p-2 rounded-lg ${activeTab === 'history' ? 'bg-slate-800' : ''}`} title="기록 피드"><LayoutDashboard size={20}/></button>
            <button onClick={() => setActiveTab('community')} className={`p-2 rounded-lg ${activeTab === 'community' ? 'bg-slate-800' : ''}`} title="커뮤니티"><Users size={20}/></button>
            <button onClick={() => setActiveTab('store')} className={`p-2 rounded-lg ${activeTab === 'store' ? 'bg-slate-800' : ''}`} title="상점"><StoreIcon size={20}/></button>
          </div>
        </div>

        {activeTab === 'history' && (
          <section className="space-y-8 animate-in fade-in duration-500">
             <header className="mb-10">
              <h2 className="text-3xl md:text-4xl font-extrabold mb-2">실패를 자산으로</h2>
              <p className="text-slate-400">자신의 실수를 기록하고 500P를 적립하세요.</p>
            </header>
            <FailureForm onAdd={addLog} />
            
            <div className="space-y-6">
              <h3 className="text-xl font-bold flex items-center gap-2 mt-10">나의 기록들</h3>
              {logs.length === 0 ? (
                <div className="text-center py-20 bg-slate-900/50 rounded-3xl border border-slate-800 border-dashed">
                  <AlertCircle className="mx-auto text-slate-600 mb-4" size={48} />
                  <p className="text-slate-500">아직 기록된 실패가 없습니다. 첫 실패를 자산으로 등록해보세요.</p>
                </div>
              ) : (
                logs.map(log => (
                  <FailureItem key={log.id} log={log} onDelete={() => deleteLog(log.id)} />
                ))
              )}
            </div>
          </section>
        )}

        {activeTab === 'community' && (
          <section className="space-y-6 animate-in fade-in duration-500">
            <header className="mb-8">
              <h2 className="text-3xl font-extrabold mb-2 flex items-center gap-3">
                <Users size={32} className="text-red-500" /> 커뮤니티
              </h2>
              <p className="text-slate-400">다른 수험생들의 실패 패턴을 분석하세요. (열람 시 100P 소모)</p>
            </header>

            {!user.hasContributed ? (
              <div className="bg-slate-900/80 border border-slate-800 p-12 rounded-3xl text-center backdrop-blur-sm">
                <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl">
                  <Lock size={32} className="text-slate-500" />
                </div>
                <h4 className="text-xl font-bold mb-3">콘텐츠 잠김</h4>
                <p className="text-slate-500 mb-8 max-w-sm mx-auto">
                  커뮤니티를 열람하려면 최소 1개 이상의 실패 기록을 작성해야 합니다. 
                </p>
                <button 
                  onClick={() => setActiveTab('history')}
                  className="bg-red-600 hover:bg-red-700 px-8 py-3 rounded-2xl font-bold transition-all"
                >
                  나의 실패 기록하기
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                  <input 
                    placeholder="검색어 입력 (예: 수학, 국어, 긴장)" 
                    className="w-full bg-slate-900 border border-slate-800 p-4 pl-12 rounded-2xl text-sm focus:border-red-500 outline-none transition-all"
                  />
                </div>
                {communityLogs.map(log => (
                  <FailureItem 
                    key={log.id} 
                    log={log} 
                    isCommunity 
                    isLocked={!user.unlockedLogIds.includes(log.id) && log.authorId !== 'me'}
                    onLike={() => handleLike(log.id)} 
                    onUnlock={() => handleUnlock(log.id)}
                  />
                ))}
              </div>
            )}
          </section>
        )}

        {activeTab === 'stats' && (
          <section className="space-y-6 animate-in fade-in duration-500">
            <h3 className="text-3xl font-extrabold mb-6">데이터 분석</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800">
                <h4 className="text-sm font-semibold text-slate-400 mb-4 uppercase tracking-widest">나의 실패 원인 분포</h4>
                <FailureChart logs={logs} />
              </div>
              <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 flex flex-col justify-center text-center">
                 <h4 className="text-sm font-semibold text-slate-400 mb-6 uppercase tracking-widest">포인트 적립 현황</h4>
                 <div className="flex flex-col items-center gap-4">
                    <div className="relative">
                       <svg className="w-32 h-32 transform -rotate-90">
                          <circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-slate-800" />
                          <circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-amber-500" strokeDasharray={364} strokeDashoffset={364 - (user.points / 10000) * 364} strokeLinecap="round" />
                       </svg>
                       <div className="absolute inset-0 flex items-center justify-center font-black text-xl">
                          {Math.floor((user.points / 10000) * 100)}%
                       </div>
                    </div>
                    <p className="text-sm text-slate-400">보유: {user.points.toLocaleString()} P</p>
                 </div>
              </div>
            </div>
          </section>
        )}

        {activeTab === 'store' && (
          <Store user={user} onPurchase={handlePurchase} />
        )}
      </main>
    </div>
  );
};

interface FailureItemProps {
  log: FailureLog;
  onDelete?: () => void;
  isCommunity?: boolean;
  isLocked?: boolean;
  onLike?: () => void;
  onUnlock?: () => void;
}

const FailureItem: React.FC<FailureItemProps> = ({ log, onDelete, isCommunity, isLocked, onLike, onUnlock }) => (
  <article className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden hover:border-slate-700 transition-all shadow-lg group relative">
    <div className={`p-6 md:p-8 ${isLocked ? 'blur-sm select-none pointer-events-none grayscale' : ''}`}>
      <div className="flex justify-between items-start mb-4">
        <div>
          <span className="inline-block px-2 py-1 rounded bg-slate-800 text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-2">
            {isCommunity ? `@${log.authorName}` : log.category} • {log.date}
          </span>
          <h4 className="text-xl font-bold group-hover:text-red-400 transition-colors">{log.title}</h4>
        </div>
        {!isCommunity && onDelete && (
          <button onClick={onDelete} className="text-slate-600 hover:text-red-500 p-2 transition-colors">
            <Trash2 size={18} />
          </button>
        )}
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        {log.tags.map(tag => (
          <span key={tag} className="text-xs bg-slate-800/80 text-slate-300 px-2 py-1 rounded-lg border border-slate-700">
            #{tag}
          </span>
        ))}
      </div>

      <p className="text-slate-400 text-sm leading-relaxed mb-6 whitespace-pre-wrap italic border-l-2 border-slate-800 pl-4">
        {log.description}
      </p>

      {log.aiAdvice && (
        <div className="bg-gradient-to-br from-indigo-900/30 to-purple-900/30 border border-indigo-500/30 rounded-2xl p-5 relative overflow-hidden mb-4">
          <div className="flex items-center gap-2 mb-3 text-indigo-300 font-bold text-sm">
            <Sparkles size={16} /> AI 통합 처방전 (Peer 비교 포함)
          </div>
          <div className="text-slate-300 text-sm leading-relaxed whitespace-pre-wrap prose prose-invert prose-sm max-w-none">
            {log.aiAdvice.split('\n').map((line, i) => (
              <p key={i} className="mb-1">{line}</p>
            ))}
          </div>
          <div className="absolute -right-4 -bottom-4 opacity-10 rotate-12"><Quote size={80} /></div>
        </div>
      )}

      {isCommunity && (
        <div className="flex items-center gap-4 mt-6 pt-4 border-t border-slate-800">
          <button onClick={onLike} className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-red-500 transition-colors">
            <ThumbsUp size={16} /> {log.likes} 도움이 돼요
          </button>
          <button className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-slate-300 transition-colors">
            <ThumbsDown size={16} /> 별로예요
          </button>
        </div>
      )}
    </div>

    {/* Lock Overlay */}
    {isLocked && (
      <div className="absolute inset-0 z-10 flex flex-col items-center justify-center p-6 text-center bg-slate-950/20 backdrop-blur-[2px]">
        <div className="bg-slate-800 p-4 rounded-full mb-4 shadow-2xl border border-slate-700">
          <Lock size={32} className="text-amber-500" />
        </div>
        <h5 className="font-bold text-lg mb-2">잠긴 실패 사례</h5>
        <p className="text-slate-400 text-sm mb-6 max-w-xs">
          이 사례의 AI 비교 분석 및 해결 전략을 확인하려면 100P가 필요합니다.
        </p>
        <button 
          onClick={onUnlock}
          className="bg-amber-500 hover:bg-amber-600 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 transition-all shadow-lg"
        >
          <Unlock size={18} /> 100P로 열람하기
        </button>
      </div>
    )}
  </article>
);

export default App;
