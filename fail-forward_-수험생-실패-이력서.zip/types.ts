
export type FailureCategory = 'Mock Exam' | 'Daily Plan' | 'Health/Mental' | 'Study Method' | 'Mock Interview';

export interface FailureLog {
  id: string;
  authorId: string;
  authorName: string;
  title: string;
  date: string;
  category: FailureCategory;
  score?: string;
  tags: string[];
  description: string;
  aiAdvice?: string;
  createdAt: number;
  likes: number;
  dislikes: number;
  isPublic: boolean;
  rewardClaimed: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  points: number;
  hasContributed: boolean;
  inventory: string[];
  unlockedLogIds: string[]; // List of community log IDs user has paid to view
}

export interface StoreItem {
  id: string;
  name: string;
  price: number;
  image: string;
  brand: string;
}

export interface TagOption {
  id: string;
  label: string;
  category: 'behavior' | 'mental' | 'method';
}

export const FAILURE_TAGS: TagOption[] = [
  { id: 'time-mgmt', label: '시간 조절 실패', category: 'behavior' },
  { id: 'sleep-dep', label: '수면 부족', category: 'behavior' },
  { id: 'overthinking', label: '과도한 고민(함정)', category: 'mental' },
  { id: 'anxiety', label: '긴장/불안감', category: 'mental' },
  { id: 'lack-of-concept', label: '개념 부족', category: 'method' },
  { id: 'careless-mistake', label: '실수(계산/마킹)', category: 'behavior' },
  { id: 'burnout', label: '무기력/번아웃', category: 'mental' },
  { id: 'distraction', label: '스마트폰/집중력', category: 'behavior' },
];

export const STORE_ITEMS: StoreItem[] = [
  { id: 'cu-5k', name: 'CU 모바일 상품권 5천원', price: 5000, brand: 'CU', image: '🏪' },
  { id: 'sb-ame', name: '스타벅스 아메리카노', price: 4500, brand: 'Starbucks', image: '☕' },
  { id: 'gs-3k', name: 'GS25 상품권 3천원', price: 3000, brand: 'GS25', image: '🍦' },
  { id: 'mc-sang', name: '맥도날드 상하이 버거', price: 6000, brand: 'McDonalds', image: '🍔' },
];
